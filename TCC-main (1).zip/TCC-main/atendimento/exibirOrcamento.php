<?php
  //  require "../seguranca.php";

    include("../configurações/bootstrap.php");
    include("../configurações/menu.php");
    require "../configurações/segurança.php";
    include 'montaOrcamento.php';
